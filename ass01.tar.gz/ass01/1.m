A = load("double-house.txt")

dimensions = size(A)

[size, volume] = compute_statistics(A)
